// export const base_url = "http://192.168.1.12:6999/"
// export const base_url = "http://192.168.1.9:6999/"
// export const base_url = "http://35.181.15.128:6999/"
// export const base_url = "https://connect.rich143.com/"
export const base_url = "https://connect.rich143.com/"
// export const base_url = "http://localhost:6999/"

